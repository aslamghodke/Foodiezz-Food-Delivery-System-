
 **Admin credentials:** Username: **admin** Password: **1234**

## Technologies Used

1. PHP
2. SQL
3. BOOTSTRAP 4
4. AJAX
5. JQUERY

## System Requirements

Software : XAMPP / Wamp / Mamp/ Lamp \(anyone\).

## Want custom PHP project?

